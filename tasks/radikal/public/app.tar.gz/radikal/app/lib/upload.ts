import path from 'path';
import { ensureDirectory } from '@/app/lib/fs';

// In dev server `/public/` will be handled by Next.js, in production we handle it by web server.
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), 'public', 'uploads');

export function getUploadDir() {
  ensureDirectory(UPLOAD_DIR);
  return UPLOAD_DIR;
}
